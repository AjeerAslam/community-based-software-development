from django.urls import path,include
from . import views

urlpatterns = [
    
    #path('', views.ex_myworks,name='ex_myworks'),
    
    #path('',views.file),
    
    #path('file_upload/', views.file_upload,name='file_upload'),
    
    
    #login
    path('',views.ex_login),
    path('expert_login/', views.ex_login_verification,name='expert_login'),
    
    #projects
    path('ex_home/', views.ex_home,name='ex_home'),
        path('accept/', views.accept ),
    path('ex_myworks/', views.ex_myworks,name='ex_myworks'),
        path('project_close/', views.project_close,name="project_close"),
    path('ex_review/', views.ex_review,name='ex_review'),
    path('ex_completed/', views.ex_completed,name='ex_completed'),

    #modules
    path('ex_new_modules/',views.ex_new_modules,name='ex_new_modules'),
        path('module_creation/', views.module_creation,name="module_creation"),
    path('ex_manage_modules/',views.ex_manage_modules,name='ex_manage_modules'),
    path('ex_review_modules/',views.ex_review_modules,name='ex_review_modules'),
    path('ex_completed_modules/',views.ex_completed_modules,name='ex_completed_modules'),
    

     

]