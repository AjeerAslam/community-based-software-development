<?php
include("connect.php");
echo<<<EOL

<doctype html>
<head>
<title>software devolepment</title>
<style>
 #b{

        position: relative;
        width: 437px;
        height: 264px;
        left: 158px;
        top: 163px;
        background: #E7E7E7;
     }
     #Reopen
     {
        

        background: #2164C9;
        box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);
        border-radius: 4px;
        position: absolute;
        width: 437px;
        height: 62px;
        left: 0px;
        bottom: 0px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 700;
        font-size: 24px;
        line-height: 29px;

        color: #FFFFFF;

     } #p
     {
        position: absolute;
        bottom: -10px;
        right: -7px;

     }
     
    
#f
{ position: absolute;
 
left:35%;
top:10%;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;

color: #000000;
}
#d
{
    position: absolute;
left:35%;
top:35%;

font-family: 'Inter';
font-style: normal;
font-weight: 300;
font-size: 24px;
line-height: 29px;
text-align: center;

color: #000000;
}
#dwn{
    position: absolute;
    right: 0px;
    top: 0px;

   
            
        }

#b{

        position: relative;
        width: 437px;
        height: 264px;
        left: 158px;
        top: 163px;
        background: #E7E7E7;
     }
     #Rework
     {
        

        background: #2164C9;
        box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);
        border-radius: 4px;
        position: absolute;
        width: 217px;
        height: 62px;
        left: 0px;
        bottom: 0px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 700;
        font-size: 24px;
        line-height: 29px;

        color: #FFFFFF;

     } #p
     {
        position: absolute;
        bottom: -10px;
        right: -7px;

     }
     
     #accept
        
     {
       

       background: #2164C9;
        box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);
        border-radius: 4px;

    
       position: absolute;
       width: 217px;
       height: 62px;
       right:0px ;
       bottom: 0px;

       font-family: 'Inter';
       font-style: normal;
       font-weight: 700;
       font-size: 24px;
       line-height: 29px;

color: #FFFFFF;

     }
#f
{ position: absolute;
 
left:35%;
top:10%;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;

color: #000000;
}
#d
{
    position: absolute;
left:35%;
top:35%;

font-family: 'Inter';
font-style: normal;
font-weight: 300;
font-size: 24px;
line-height: 29px;
text-align: center;

color: #000000;
}
#dwn{
    position: absolute;
    right: 0px;
    top: 0px;

   
            
        }


#dashboard{
position: absolute;
width: 235px;
height: 98px;
left: 0px;
top: 0px;
background: #3C59F0;
box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);
}
#dashboard img{
position: absolute;
width: 84px;
height: 90px;
left: 151px;
top: 9px;
}
#header{
box-sizing: border-box;

position: absolute;
width: 1284px;
height: 99px;
left: 235px;
top: 0px;

background: #3C59F0;
border: 1px solid #000000;
}
#nav{
position: absolute;
width: 237px;
height: 925px;
left: -2px;
top: 99px;
overflow-y: hidden;
background: #3C59F0;
box-shadow: 5px 4px 4px rgba(0, 0, 0, 0.25);
}
#section{
position: absolute;
width: 1284px;
height: 923px;
left: 235px;
top: 99px;
overflow:scroll;
background: #F5F5F5;
}

#n1 {
position: absolute;
left: 16px;
top: 30px;


}
#n2{
position: absolute;
left: 10px;
top: 113px;
}
#n3{
position: absolute;
left: 16px;
top: 202px;
}
#n4{
position: absolute;
left: 16px;
top: 297px;
}
#a11{
position: absolute;
width: 139px;
height: 56px;
left: 50px;
top: 40px;

font-family: 'Inter';
font-style: normal;
font-weight: 500;
font-size: 24px;
line-height: 29px;

color: #100F0F;
}
#a22{
position: absolute;
width: 300px;
height: 56px;
left: 200px;
top: 40px;

font-family: 'Inter';
font-style: normal;
font-weight: 500;
font-size: 24px;
line-height: 29px;

color: #FFADAD;
}
#a33{
position: absolute;
width: 340px;
height: 42px;
left: 900px;
top: 45px;

font-family: 'Inria Serif';
font-style: normal;
font-weight: 700;
font-size: 20px;
line-height: 24px;
text-align: center;

color: #FFFFFF;
}

#a55{
position: absolute;
width: 91px;
height: 53px;
left: 1050px;
top: 1px;
}


#header img{
position: absolute;
width: 59px;
height: 48px;
left: 154px;
top: 30px;
}
#n1 a{
position: relative;
top: -6;
left: 17px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;

color: #292020;
}
#n2 a{
position: relative;
top: -12px;
left: 25px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;

color: #292020;
}
#n3 a{
position: relative;
top:-9 ;
left: 17px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;

color: #292020;
}
#n4 a{
position: relative;
top: -10;
left: 20px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;

color: #292020;
}
#d1{
position: absolute;
width: 68px;
height: 57px;
left: 1140px;
top: 21px;

background: #41242F;
border-radius: 8px;
}
#a44 span{
position: relative;
width: 104px;
height: 52px;
top: 5px;
left: 20px;

font-family: 'Inria Serif';
font-style: normal;
font-weight: 400;
font-size: 40px;
line-height: 48px;
text-align: center;

color: #FFFBFB;


}
#b{

        position: relative;
        width: 437px;
        height: 264px;
        left: 150px;
        top: 100px;
        background: #E7E7E7;
     }
     #u
     {
        position: absolute;
        bottom: -10px;

     } #p
     {
        position: absolute;
        bottom: -10px;
        right: -7px;

     }
     
    } #p1
     {
        position: absolute;
       
        right: -120%;

     }
#f
{ position: absolute;
 
left:35%;
top:10%;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;

color: #000000;
}
#d
{
position: absolute;
left:35%;
top:35%;

font-family: 'Inter';
font-style: normal;
font-weight: 300;
font-size: 24px;
line-height: 29px;
text-align: center;

color: #000000;
}
a{
	cursor: pointer;
}
/*popup*/
#box{    
box-sizing: border-box;
display:none;
outline:0;
width: 735px;
height: 1005px;
left: 0px;
top: 0px;
background-color: antiquewhite;

background: #FFFFFF;
border: 1px solid #000000;
border-radius: 34px;
}
#name{
        
box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 135.21px;
top: 133.61px;

background: #D9D9D9;

border-radius: 23px;
    }
#email{
   box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 135.21px;
top: 233.71px;
background: #D9D9D9;
border-radius: 23px;  
    }
#no{
     box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 135px;
top: 374.5px;

background: #D9D9D9;
border-radius: 23px;   
    }
#profession{
        
box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 133px;
top: 507.5px;

background: #D9D9D9;
border: 1px solid #000000;
border-radius: 23px;
    }
#skill{
        box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 133px;
top: 637.5px;

background: #D9D9D9;
border: 1px solid #000000;
border-radius: 23px;
    }
#address{
        box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 80.48px;
left: 135px;
top: 763.5px;

background: #D9D9D9;
border: 1px solid #000000;
border-radius: 23px;
        
    }
#update{
        position: absolute;
width: 261px;
height: 66px;
left: 237px;
top: 888px;

        
    }
    #profile{
        position: absolute;
width: 437px;
height: 60px;
left: 255px;
top: 30px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 40px;
line-height: 48px;

color: #100F0F;



        
    }
    #n{
        position: absolute;
width: 91.12px;
height: 38.28px;
left: 135.21px;
top: 90.42px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;
/* identical to box height */


color: #121010;



        
    }
    #e{
        position: absolute;
width: 85.12px;
height: 22.57px;
left: 135.21px;
top: 189.55px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;

color: #201B1B;


        
    }
    #pn{
        position: absolute;
width: 158.22px;
height: 38.28px;
left: 135px;
top: 305.5px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;



color: #201B1B;
        
    }
    #pr{
        position: absolute;
width: 168.23px;
height: 38.28px;
left: 135px;
top: 442.5px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;
/* identical to box height */


color: #201B1B;



        
    }
    #sk{
        position: absolute;
width: 84.11px;
height: 22.57px;
left: 135px;
top: 579.5px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;

color: #201B1B;


        
    }
    #add{
        position: absolute;
width: 187.25px;
height: 22.57px;
left: 130px;
top: 705.5px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 32px;
line-height: 39px;

color: #201B1B;



        
    }
    #btn{
        position: absolute;
width: 261px;
height: 66px;
left: 237px;
top: 888px;
        font-weight: 700;
font-size: 32px;
        
    }
    #btn1{
        position: absolute;
width: 261px;
height: 66px;
left: 1114px;
top: 546px;

background: #3C59F0;
box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 4px;
font-weight: 700;
font-size: 32px;
position: absolute;
width: 165.69px;
height: 29.31px;
left: 1155.79px;
top: 571.38px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;
text-align: center;

color: #FFFFFF;

        
    }
#t1{
    display: none;
}
#t2{
    display: none;
}
#t3{
    display: none;
}
#t4{
    display: none;
}
#progress{
position: absolute;
width: 437px;
height: 60px;
left: 0px;
top: 202px;

background: #3C59F0;

}
#per{
position: relative;
width: 54px;
height: 29px;
left: 300px;
top: -60px;

background: #ffffff;
}
#p5{
position: relative;
width: 54px;
height: 6px;
left:2px;
top: 0px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;
/* identical to box height */


color: #000000;
}
#p3{
position: relative;
left: 90px;
top: -5px;

font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;

color: #000000;



font-family: 'Inter';
font-style: normal;
font-weight: 700;
font-size: 24px;
line-height: 29px;

    color: #000000;}    
#box{    
box-sizing: border-box;
outline:0;
width: 735px;
height: 1005px;
left: 0px;
top: 0px;
background-color: antiquewhite;

background: #FFFFFF;
border: 1px solid #000000;
border-radius: 34px;
}
#name{
        
box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 135.21px;
top: 130px;

background: #D9D9D9;

border-radius: 23px;
    }
#type{
   box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 135.21px;
top: 233.71px;
background: #D9D9D9;
border-radius: 23px;  
    }
#no{
     box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 135px;
top: 350.5px;

background: #D9D9D9;
border-radius: 23px;   
    }
#profession{
        
box-sizing: border-box;

position: absolute;
width: 431.59px;
height: 41.22px;
left: 133px;
top: 507.5px;

background: #D9D9D9;
border: 1px solid #000000;
border-radius: 23px;
    }

    #rs{
        position: absolute;
        width: 437px;
        height: 60px;
        left: 150px;
        top: 10px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 60px;
        font-size: 30px;
        line-height: 48px;

        color: #100F0F;



        
    }
    #n{
        position: absolute;
        width: 412px;
        height: 38.28px;
        left: 135.21px;
        top: 90.42px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 30;
        font-size: 24px;
        line-height: 39px;
/* identical to box height */


        color: #121010;



        
    }
    #tp{
        position: absolute;
        width: 412px;
        height: 22.57px;
        left: 135.21px;
        top: 189.55px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 30;
        font-size: 24px;
        line-height: 39px;

        color: #201B1B;


        
    }
    #r{
        position: absolute;
         width: 412px;
        height: 900px;
        left: 135px;
        top: 305.5px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 30;
        font-size: 24px;
        line-height: 39px;



        color: #201B1B;
        
    }
    #dd{
        position: absolute;
        width: 168.23px;
        height: 38.28px;
        left: 135px;
        top: 450.5px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 30;
        font-size: 24px;
        line-height: 39px;
       /* identical to box height */


        color: #201B1B;



        
    }
    
    
    #du{
        position: absolute;
        width: 158.22px;
        height: 38.28px;
        left: 135px;
        top: 410.5px;

        font-family: 'Inter';
        font-style: normal;
        font-weight: 30;
        font-size: 24px;
        line-height: 39px;



        color: #201B1B;
        
        
    }
    #ss{
        background: #2164C9;
        box-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);
        border-radius: 4px;
        position: absolute;
        width: 237px;
        height: 62px;
        left: 250px;
        bottom: 0px;
        top: 550px;
        font-family: 'Inter';
        font-style: normal;
        font-weight: 700;
        font-size: 24px;
        line-height: 29px;

        color: #FFFFFF;

    }    
</style>
</head>
<body>

<div id="dashboard">
<img src="List.svg">	
</div>	
<div id="header">
<a id=a11><b>Dashboard</b></a><br>
<img src="arrow.svg">
<a id=a22><b>Review</b></a><br>
<div id=a33>Welcome user</div><br>
<a id=a44><div id=d1><span>N</span></div></a><br>
<a id=a55><img src="Logout.svg"></a><br>
</div>
<div id="nav">
<div id=n1>
<a id=a1><b>Project progress</b></a>
</div>
<div id=n2>
<a id=a2><b>Requirement submission</b></a>
</div>
<div id=n3>
<a id=a3><b>Review</b></a>
</div>
<div id=n4>
<a id=a4><b>Completed</b></a>
</div>
</div>
<div id="section">

<div>
<table  id="t1" style="position: relative;left: -30px;top: -40px;border-spacing:60px;">

EOL;

for($i=0;$i<10;$i++){

echo<<<EOL
<tr>
<td>

<div id="b" onclick="alert('div');">
<a href="" onclick="func1(event)" id="u"></a>
<a href="" onclick="func2(event)" id="p"></a>
<a href="" onclick="func3(event)" id="p1"><img src="Group 74.svg"></a>
<sec  id="f">Project 1</sec>
<div id="progress">
<p id="p3">Progress</p>
<div id="per">
<p id="p5">80%</p>
</div>
</div>
</div>
</td>
<td>
<div id="b" onclick="alert('div');">
<a href="" onclick="func1(event)" id="u"></a>
<a href="" onclick="func2(event)" id="p"></a>
<a href="" onclick="func3(event)" id="p1"><img src="Group 74.svg"></a>
<sec  id="f">Project 1</sec>
<div id="progress">
<p id="p3">Progress</p>
<div id="per">
<p id="p5">80%</p>
</div>
</div>
</div>
</td>



</tr>
EOL;
}
echo <<< EOL
</div>

<div id="t2">
<div id="section" tabindex="-1">

<form  id="myform" >
<label id="rs">REQUIREMENT SUBMISSION</label>
<label id="n">NAME OF PROJECT</label><br>    
<input type="text" id="name" name="name " >
<label id="tp">TYPE OF PROJECT</label><br> 
<input type="text" id="type" name="type" >
<label id="r">PROJECT REQUIREMENT</label><br> 
<input type="text" id="no" name="requirement" >
<label id="du">DUE DATE</label><br>
<input type="date" id="dd" name="duedate" >
<input type="submit" id="ss" name="submit" >

</form>
</div>
</div>

<table  id="t3" style="position: relative;left: -30px;top: -40px;border-spacing:60px;">
    
EOL;
    
$i=0;
    
$client_project="SELECT pr_name,pr_description FROM projects WHERE pr_status='waiting'";
    
$client_project_results=mysqli_query($con,$client_project);
    
while($row=mysqli_fetch_assoc($client_project_results))

{
    $pr_name=$row['pr_name'];
    $pr_desc=$row['pr_description'];
  



if($i%2==1)
{
 
echo<<<EOL
<tr>
<td>
<div id="b" onclick="alert('div');">
<a id="re"><button id="Rework">Rework</button></a>
<a id="acc"><button id="accept">Accept</button></a>
<a href="" onclick="func3(event)" id="dwn"><img src="clientdwnl.svg"></a>

<a href="" onclick="func3(event)" id="p1"><img src="Group 74.svg"></a>
EOL;
echo<<<EOL
<sec  id="f">$pr_name</sec>
<p id="d">$pr_desc</p>
</div>
</td>
EOL;
}
else 
{
echo<<<EOL
<td>
<div id="b" onclick="alert('div');">
<a id="re"><button id="Rework">Rework</button></a>
<a id="acc"><button id="accept">Accept</button></a>
<a href="" onclick="func3(event)" id="dwn"><img src="clientdwnl.svg"></a>

<a href="" onclick="func3(event)" id="p1"><img src="Group 74.svg"></a>
<sec  id="f">$pr_name</sec>
<p id="d">$pr_desc</p>
</div>
</td>
</tr>
EOL;
}
$i++;
}
if ($i==0)
{
    echo<<<EOL
    <tr>
    <td>NO WORKS</td>
    EOL;
}

echo<<<EOL
</table>
</div>

    
<table  id="t4" style="position: relative;left: -30px;top: -40px;border-spacing:60px;">
EOL;

for($i=0;$i<10;$i++){  
echo<<<EOL
<tr>
<td>
<div id="b" onclick="alert('div');">
<a id="re"><button id="Reopen">Reopen</button></a>

<a href="" onclick="func3(event)" id="dwn"><img src="clientdwnl.svg"></a>

<a href="" onclick="func3(event)" id="p1"><img src="Group 74.svg"></a>
<sec  id="f">Project1</sec>
<p id="d">Description</p>

</div>



</td>
<td>
<div id="b" onclick="alert('div');">
<a id="re"><button id="Reopen">Reopen</button></a>

<a href="" onclick="func3(event)" id="dwn"><img src="clientdwnl.svg"></a>

<a href="" onclick="func3(event)" id="p1"><img src="Group 74.svg"></a>
<sec  id="f">Project1</sec>
<p id="d">Description</p>

</div>

</td>



</tr>
EOL;
}
?>

</div>
  


    





</div>
<script>
/*module*/
 function func1(event) {
             event.stopPropagation();
         
             alert("upload");
          
        }
        function func2(event) {
             event.stopPropagation();
         
             alert("progress");
          
        }
        function func3(event) {
             event.stopPropagation();
         
             alert("project details");
          
        }
/*popup*/

/*layout*/
function click()
{
 document.getElementById("a22").innerHTML="Project progress";      
document.getElementById("t1").style.display= "block";
document.getElementById("t2").style.display= "none";
document.getElementById("t3").style.display= "none";
document.getElementById("t4").style.display= "none";
document.getElementById("a1").style.color= "white";
document.getElementById("a2").style.color= "black";
document.getElementById("a3").style.color= "black";
document.getElementById("a4").style.color= "black";
}
document.getElementById("a1").addEventListener("click",click);

function click1()
{
document.getElementById("a22").innerHTML="Requirement submission";
document.getElementById("t1").style.display= "none";
document.getElementById("t2").style.display= "block";
document.getElementById("t3").style.display= "none";
document.getElementById("t4").style.display= "none";
document.getElementById("a2").style.color= "white";
document.getElementById("a1").style.color= "black";
document.getElementById("a3").style.color= "black";
document.getElementById("a4").style.color= "black";
}
document.getElementById("a2").addEventListener("click",click1);

function click2()
{
document.getElementById("a22").innerHTML="Review";
document.getElementById("t1").style.display= "none";
document.getElementById("t2").style.display= "none";
document.getElementById("t3").style.display= "block";
document.getElementById("t4").style.display= "none";
document.getElementById("a3").style.color= "white";
document.getElementById("a2").style.color= "black";
document.getElementById("a1").style.color= "black";
document.getElementById("a4").style.color= "black";
}
document.getElementById("a3").addEventListener("click",click2);
function click3()
{
document.getElementById("a22").innerHTML="Completed";
document.getElementById("t1").style.display= "none";
document.getElementById("t2").style.display= "none";
document.getElementById("t3").style.display= "none";
document.getElementById("t4").style.display= "block";
document.getElementById("a4").style.color= "white";
document.getElementById("a2").style.color= "black";
document.getElementById("a3").style.color= "black";
document.getElementById("a1").style.color= "black";
}
document.getElementById("a4").addEventListener("click",click3);
function click4()
{
document.getElementById('section').innerHTML = 'violet';
}
document.getElementById("a11").addEventListener("click",click4);
function click5()
{
document.getElementById('section').innerHTML = 'black';
}
document.getElementById("a22").addEventListener("click",click5);


function click6()
{
document.getElementById('section').innerHTML = 'puple';
}
document.getElementById("a33").addEventListener("click",click6);
function click7()
{
document.getElementById('section').innerHTML = 'pink';
}
document.getElementById("a44").addEventListener("click",click7);
function click8()
{
document.getElementById('section').innerHTML = 'lavender';
}
document.getElementById("a55").addEventListener("click",click8);
</script>
</body>
</html>